# SleepFix

Website Sleep Planner yang sudah disiapkan untuk GitHub Pages dan PWA.

## Sebelum dipublikasikan
Ganti `USERNAME` pada:
- `index.html` (canonical, Open Graph image, Twitter image)
- `sitemap.xml`
- `robots.txt`

Gunakan nama akun GitHub Anda. Jika nama repository bukan `SleepFix`, sesuaikan juga path repository pada URL.

## File utama
- `index.html` — aplikasi SleepFix (fitur asli dipertahankan)
- `manifest.json` — metadata instalasi PWA
- `service-worker.js` — cache offline dasar
- `sitemap.xml` dan `robots.txt` — SEO
- `assets/` — ikon dan gambar berbagi

## Catatan PWA
Service worker dan instalasi PWA membutuhkan HTTPS (GitHub Pages menyediakannya). Offline pertama kali baru tersedia setelah situs berhasil dibuka online dan service worker selesai terpasang. Fitur yang memerlukan koneksi internet atau API eksternal mungkin tidak tersedia offline.

## Publikasi GitHub Pages
1. Buat repository GitHub bernama `SleepFix` (atau sesuaikan URL).
2. Upload seluruh ISI folder ini ke root repository, bukan folder pembungkus.
3. Buka Settings > Pages.
4. Pada Build and deployment pilih Deploy from a branch, branch `main`, folder `/ (root)`, lalu Save.
5. Tunggu sampai GitHub Pages memberi URL publik.

## Google Search Console
1. Buka https://search.google.com/search-console/
2. Tambahkan properti URL-prefix menggunakan URL GitHub Pages.
3. Verifikasi sesuai metode yang ditawarkan Google (misalnya HTML file atau tag).
4. Setelah website online, kirim sitemap: `https://USERNAME.github.io/SleepFix/sitemap.xml`.
5. Gunakan URL Inspection untuk meminta pengindeksan halaman utama.

Google tidak menjamin halaman langsung muncul atau berada di posisi tertentu. Pastikan URL canonical dan sitemap sudah memakai URL publik sebenarnya.
